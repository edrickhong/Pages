Assets here are used for testing purposes only. These files are automatically downloaded by the CI system and fed to a test program.

hash_list.txt is used to generate the array found in hash_array.h


