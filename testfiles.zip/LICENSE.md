Animated Knight by Clement Wu, Nikolaus & Botanic CC-3.0 [http://creativecommons.org/licenses/by/3.0/]
lava golem CC0 [https://creativecommons.org/publicdomain/zero/1.0/]

